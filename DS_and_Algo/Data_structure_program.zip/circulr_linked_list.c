#include<stdio.h>
#include<stdlib.h>

typedef struct Node{

    int val;
    struct Node* next;
}snode;

snode* create_node (int);
void insert_node_first();
void insert_node_last();
void print_linked_list();
void insertion();
void insert_node_between();
void delete_node();


int node_cnt = 0;
snode *head= NULL, *node, *last=NULL;

int main()
{

    int choice = 0;

    while(1)
    {
        printf("\n\tMenu for linked list:-\n");
        printf("-------------------------------------------\n\n");
        printf("\t\t1. Insert a node.\n");
        printf("\t\t2. Delete a node.\n");
        printf("\t\t3. Print a linked list.\n");
        printf("\t\t4. Exit\n");

        printf("\nEnter your choice: ");
        scanf("%d",&choice);

        switch(choice){
        case 1:
            insertion();
            break;
        case 2:
            delete_node();
            break;
        case 3:
            print_linked_list();
            break;
        case 4:
            exit(0);
            break;
        default:
            printf("\nInvalid choice\n\n");
            break;

        }
    }
    return 0;
}

snode *create_node(int val){

        node = (snode*)malloc(sizeof(snode));

        if(node == NULL)
        {
            printf("\nMemory is not allocated.");
            return 0;
        }
        else{
            node->val = val;
            node->next = NULL;
            return node;
        }
}
void insertion()
{
    int choice;
    printf("\n\t1. Insert at first.");
    printf("\n\t2. Insert at last.");
     printf("\n\t3. Insert at middle.");

    printf("\nEnter your choice:- ");
    scanf("%d",&choice);

    switch(choice)
    {
    case 1:
        insert_node_first();
        break;
    case 2:
        insert_node_last();
        break;
    case 3:
        insert_node_between();
        break;

    }
}
void insert_node_first(){
    int val;

    printf("\nEnter value of node:- ");
    scanf("%d",&val);

    node = create_node(val);

    if(head==NULL){
        head = last = node;
        last->next=head;
        node_cnt++;
    }
    else{
        node->next = head;
        head = node;
        last->next = head;
        node_cnt++;
    }
}

void insert_node_last(){

    int val;

    printf("\nEnter value of node:- ");
    scanf("%d",&val);

    node = create_node(val);

    if(head==NULL){
        head =last =node;
        last->next=head;
        node_cnt++;
    }
    else{
        node->next=last->next;
        last->next= node;
        last = node;
        node_cnt++;
    }
}

void insert_node_between()
{
    int position=0;

    while(position<1 || position>node_cnt)
    {
        printf("\n\tEnter -1 to exit.\n");
        if(node_cnt==0){
            printf("\nEnter a number between(1-%d):- ",node_cnt+1);
            scanf("%d",&position);
            if(position>=1 && position<=node_cnt+1)
            break;
        }
        else{
            printf("\nEnter a number between(1-%d):- ",node_cnt);
            scanf("%d",&position);
            if(position>=1 && position<=node_cnt)
            break;
        }

        if(position!=-1 /*&& position!=0*/)
            printf("\n\tYour entered position is not exist.");
        else if(position==-1){
            return ;
        }
    }
    if(position==1 /*|| position==0*/)
    {
        insert_node_first();
    }
    else if(position==node_cnt)
    {
        insert_node_last();
    }
    else{
        snode* temp;
        int i,val;

        temp=last;
        for(i=1; i<position-1; i++){
             temp=temp->next;
        }

        printf("\nEnter value of node:- ");
        scanf("%d",&val);

        node = create_node(val);

        node->next = temp->next;
        temp->next = node;
        //last=node;
        node_cnt++;
    }
}

void delete_node(){

    if(head==NULL){
        printf("\n\tlinked list is empty.\n");
    }
    else
    {
        int position;
        snode* temp,*target;
        printf("Enter a position to be delete(1-%d):-",node_cnt);
        scanf("%d",&position);

        if(position>=1 && position<=node_cnt)
        {
            temp = head;
            if(position == 1)
            {
                if(head==last){
                    free(head);
                    head=last=NULL;
                }
                else
                {
                    head = head->next;
                    last->next = head;
                    temp->next = NULL;
                    free(temp);
                }
                node_cnt--;
            }
            else if(position==node_cnt){
                int i;
                //temp  = head;
                for(i=1; i<position-1; i++)
                {
                    temp= temp->next;
                }
                target = temp->next;
                temp->next = target->next;
                last = temp;
                target->next =NULL;
                free(target);
                node_cnt--;
            }
            else if(position<=node_cnt){
                int i;
                //temp  = head;
                for(i=1; i<position-1; i++)
                {
                    temp= temp->next;
                }
                target = temp->next;
                temp->next = target->next;
                target->next =NULL;
                free(target);
                node_cnt--;
            }

        }
    }
}

void print_linked_list(){

    snode* temp;
    if(/*head == NULL ||*/ last==NULL){
        printf("\nLinked List is empty.");
        return;
    }
    temp=last;
    do
    {
        printf("%d->",temp->val);
        temp=temp->next;
    }
    while(temp!=last);
    printf("\n%d",node_cnt);
}
