#include <stdio.h>

void printMatrix(int*,int,int);
void getMatrix(int* ,int,int);
void mulMatrix(int*,int,int,int*,int,int,int*);

int main()
{
    int  r1, c1, r2, c2, i, j, k;

    printf("Enter rows and column for first matrix: ");
    scanf("%d %d", &r1, &c1);

    printf("Enter rows and column for second matrix: ");
    scanf("%d %d",&r2, &c2);

    int mat_1[r1][c1], mat_2[r2][c2], final_mat[r2][c1];

    while (c1 != r2)
    {
        printf("Error! column of first matrix not equal to row of second.\n\n");
        printf("Enter rows and column for first matrix: ");
        scanf("%d %d", &r1, &c1);
        printf("Enter rows and column for second matrix: ");
        scanf("%d %d",&r2, &c2);
    }

    printf("\nEnter elements of matrix 1:\n\n\n");
    getMatrix((int *)mat_1,r1,c1);

    printf("\nEnter elements of matrix 2:\n\n\n");
    getMatrix((int*)mat_2,r2,c2);

    for(i=0; i<r1; ++i)
        for(j=0; j<c2; ++j)
        {
            final_mat[i][j] = 0;
        }
    mulMatrix((int*)mat_1,r1,c1,(int*)mat_2,r2,c2,(int*)final_mat);
    printf("\nOutput Matrix:\n");
    printMatrix((int *)final_mat,r1,c2);

    return 0;
}
void getMatrix(int* array,int row,int col)
{
  int i,j;
  for (i=0;i<row;i++)
  {
    for(j=0;j<col;j++)
    {
         printf("Enter elements mat_1:%d%d: ",i+1, j+1);
        scanf("%d",(array+(i*col)+j));
    }
  }
}
void printMatrix(int* array,int row,int col)
{
    int i,j;
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            printf("%d  ",*(array+(i*col)+j));
        }
        printf("\n");
    }
}
void mulMatrix(int* mat_1,int r1,int c1,int* mat_2,int r2,int c2,int *final_mal)
{
    int i,j,k;

    for(i=0;i<r1;i++)
    {
        for(j=0;j<c2;j++)
        {
            for(k=0;k<r2;k++)
                {
                    *(final_mal+(i*c2)+j) += (*(mat_1+(i*c1)+k))*(*(mat_2+(k*c1)+j));
                }
        }
    }
}
