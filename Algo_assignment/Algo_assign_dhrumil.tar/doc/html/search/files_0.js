var searchData=
[
  ['min_5fsum_2ec',['min_sum.c',['../min__sum_8c.html',1,'']]]
];
