var searchData=
[
  ['outfileptr',['outFilePtr',['../Sample_8c.html#a127e7fd3047998f98386afdfb2471989',1,'Sample.c']]],
  ['outputfilename',['outputFileName',['../Sample_8c.html#ac224b2769f256d5f706fde4c2fc17a11',1,'Sample.c']]]
];
