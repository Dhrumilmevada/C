var searchData=
[
  ['infileptr',['inFilePtr',['../Sample_8c.html#aefd8ef723553b9975c9879b191221ef3',1,'Sample.c']]],
  ['inputfilename',['inputFileName',['../Sample_8c.html#a68895d33cec4d40fa3e38cb4452e0d58',1,'Sample.c']]]
];
